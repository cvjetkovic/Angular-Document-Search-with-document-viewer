export interface SearchData {
    laws: Laws[];
    total: number;
  }
  
  export interface Laws {
    number: string;
    title: string;
  }
  
  
  