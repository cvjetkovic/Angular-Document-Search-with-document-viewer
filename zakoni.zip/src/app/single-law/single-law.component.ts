import { Component, OnInit,  VERSION, Pipe, PipeTransform  } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { LawServiceService } from '../law-service.service'; 
import {BrowserModule, DomSanitizer} from '@angular/platform-browser'

export class HighlightSearch implements PipeTransform {
  constructor(private sanitizer: DomSanitizer){}

  transform(value: any, args: any): any {
    if (!args) {
      return value;
    }
    // Match in a case insensitive maneer
    const re = new RegExp(args, 'gi');
    const match = value.match(re);

    // If there's no match, just return the original value.
    if (!match) {
      return value;
    }

    const replacedValue = value.replace(re, "<mark>" + match[0] + "</mark>")
    return this.sanitizer.bypassSecurityTrustHtml(replacedValue)
  }
}


@Component({
  selector: 'app-single-law',
  templateUrl: './single-law.component.html',
  styleUrls: ['./single-law.component.scss']
})
export class SingleLawComponent implements OnInit  {
  law = '';
  doc: string = 'http://192.168.67.137:8080/aplikacija/';
  // test = "http://192.168.67.137:8080/aplikacija/downloadFile/"
  // doc: string = 'http://192.168.67.137:8080/aplikacija/downloadFile/925efd3e-80c0-46cd-9b6b-0749736926f2?fileType=word';
  searchTerm: string = ""; 
  test = "http://192.168.67.137:8080/aplikacija/downloadFile/49f4dcfa-33df-46fe-a632-0dd133eda374?fileType=word"
  constructor(private route: ActivatedRoute, private service: LawServiceService) { }

  ngOnInit(): void {  
  this.route.paramMap.subscribe( paramMap => { 
    this.law = paramMap.get('uuid');  
      this.doc = 'http://192.168.67.137:8080/aplikacija/downloadFile/'+ this.law + '?fileType=word';  
    })   
  }  

  updateSearch(e) {
    this.searchTerm = e.target.value
  }

}
